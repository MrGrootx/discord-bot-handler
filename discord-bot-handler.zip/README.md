Credits - jackson

<h1 align="center">Welcome to Discord.js v14 Handler 👋</h1>

> A handler for Discord.js v14!

## Install

```sh
npm install
```

## Setup

Environment (important)
Rename `.env-example` to `.env` and fill the following blanks:

```
//.env
TOKEN="YOUR BOT TOKEN"
CLIENT_ID="YOUR CLIENT ID"

## DATABASE
MONGODBURL="DATABASE URL HERE"

# DEV COMMEND
DEV_CMD= ["xxxxx","xxxxxx"] # (OPTIONAL)
```

## to start the bot

```sh
node . or nodemon
```

## Author

- Github: [@MrGrootx](https://github.com/MrGrootx)
- Discord account: Mr Groot#9862 (Contact for support!)
